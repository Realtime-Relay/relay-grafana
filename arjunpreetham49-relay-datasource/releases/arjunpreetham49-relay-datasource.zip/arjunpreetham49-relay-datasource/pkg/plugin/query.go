package plugin

type Query struct {
	Topic   string `json:"topic"`
}